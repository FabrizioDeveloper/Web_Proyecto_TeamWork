package pe.edu.upc.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamWorkSecurityV3Application {

	public static void main(String[] args) {
		SpringApplication.run(TeamWorkSecurityV3Application.class, args);
	}

}
